package edu.skku.map.myapplication

data class Restaurant(
    val id: Int,
    val name: String,
    val type: String,
    val location: String,
    val rating: String,
    val imageResource: Int
)
