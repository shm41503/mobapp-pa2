package edu.skku.map.myapplication

data class MenuItem(
    val imageResource: Int,
    val name: String,
    val price: Int
)
